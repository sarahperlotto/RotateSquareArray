/*
 * Written by Sarah Perlotto 11/17/2017
 */

package arraydemo;

public class TwoDimensionalArrayDemo {
    
    public static void main(String[] args) {
        int[][] array = createArray(6);
        System.out.println("Original array: ");
        printArray(array);
        System.out.println("\n\nRotated array: ");
        int[][] rotatedArray = rotateClockwise(array);
        printArray(rotatedArray);
    }
    
    //Determine whether array argument is square
    public static boolean isSquareArray(int[][] array) {
        int dimension = array.length;
        for (int i = 0; i < dimension; i++) {
            if (dimension != array[i].length) {
                return false;
            }
        }
        return true;
    }

    //Rotate a 2D square array clockwise
    public static int[][] rotateClockwise(int[][] array) {
        //Check for square - if not, return as is
        if (!isSquareArray(array)) {
            return array;
        }
        //Determine number of rotations needed
        int dimension = array.length;
        int rotations = dimension / 2; //ok for truncation, no need to rotate 1x1
        //Rotate from the outside in  
        for (int i = 0; i < rotations; i++) {
            //Complete current rotation
            for (int j = i; j < dimension - i - 1; j++) {
                int temp = array[i][j];
                array[i][j] = array[dimension - j - 1][i];
                array[dimension - j - 1][i] = array[dimension - i - 1][dimension - j - 1];
                array[dimension - i - 1][dimension - j - 1] = array[j][dimension - i - 1];
                array[j][dimension - i - 1] = temp;
            }
        }
        return array;
    }
 
    //Print contents of argument array
    public static void printArray(int[][] array) {
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[0].length; j++) {
                System.out.print(array[i][j]+ "\t");
            }
        System.out.print(" \n");
        }
    }
 
    //Create a 2D square array and load with incremental values
    public static int[][] createArray(int size) {
        if (size < 1) {
            return null;
        }
        int[][] array = new int[size][size];
        int counter = 1;
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                array[i][j] = counter++;
            }
        }
        return array;
    }
    
}
